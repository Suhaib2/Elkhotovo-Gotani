import sys
from PyQt5 import uic, QtGui
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *


class ClassName1(QMainWindow):
    def __init__(self):
        super(ClassName1, self).__init__()
        uic.loadUi('qtt.ui', self)

        # Изменение шрифта
        self.spinBox.valueChanged.connect(self.fontsize)
        self.spinBox.setRange(13, 100)

        self.plain.setFont(QtGui.QFont('Arial', 13))

        # Подключение к меню
        self.actionNew.triggered.connect(self.new)
        self.actionOpen.triggered.connect(self.open)
        self.actionSave_as.triggered.connect(self.save)

        # Темы
        self.btn_black.clicked.connect(self.theme_black)
        self.btn1.clicked.connect(self.theme)

        # Меню для тёмной темы
        self.action_Red.triggered.connect(self.theme_red)
        self.action_Blue.triggered.connect(self.theme_blue)
        self.action_Green.triggered.connect(self.theme_grenn)
        self.action_R.triggered.connect(self.theme)
        self.action_F.triggered.connect(self.theme_f)

        # Меню для тёмной темы
        self.actionRed.triggered.connect(self.theme_black_red)
        self.actionBlue.triggered.connect(self.theme_black_blue)
        self.actionGreen.triggered.connect(self.theme_black_green)
        self.actionF.triggered.connect(self.theme_black_f)
        self.actionR.triggered.connect(self.theme_black)

        self.btn1.setChecked(True)
        if self.btn1.isChecked():
            self.plain.setStyleSheet("background-color: #fff; color: #FF430A;")

    # Тёмная тема
    def theme_black(self):
        self.plain.setStyleSheet("background-color: #212121; color: #FFB14B;")
        self.btn1.setChecked(False)
        self.btn_black.setChecked(True)

    def theme_black_blue(self):
        self.plain.setStyleSheet("background-color: #212121; color: blue;")
        self.btn1.setChecked(False)
        self.btn_black.setChecked(True)

    def theme_black_red(self):
        self.plain.setStyleSheet("background-color: #212121; color: red;")
        self.btn1.setChecked(False)
        self.btn_black.setChecked(True)

    def theme_black_green(self):
        self.plain.setStyleSheet("background-color: #212121; color: green;")
        self.btn1.setChecked(False)
        self.btn_black.setChecked(True)

    def theme_black_f(self):
        self.plain.setStyleSheet("background-color: #212121; color: #B73DA3;")
        self.btn1.setChecked(False)
        self.btn_black.setChecked(True)

    # Светлая тема
    def theme(self):
        self.plain.setStyleSheet("background-color: #fff; color: #FF430A;")
        self.btn1.setChecked(True)
        self.btn_black.setChecked(False)

    def theme_red(self):
        self.plain.setStyleSheet("background-color: #fff; color: red;")
        self.btn1.setChecked(True)
        self.btn_black.setChecked(False)

    def theme_blue(self):
        self.plain.setStyleSheet("background-color: #fff; color: blue;")
        self.btn1.setChecked(True)
        self.btn_black.setChecked(False)

    def theme_grenn(self):
        self.plain.setStyleSheet("background-color: #fff; color: green;")
        self.btn1.setChecked(True)
        self.btn_black.setChecked(False)

    def theme_f(self):
        self.plain.setStyleSheet("background-color: #fff; color: purple;")
        self.btn1.setChecked(True)
        self.btn_black.setChecked(False)

# Метод для изменение шрифта
    def fontsize(self, value):
        font = QTextCharFormat()
        font.setFontPointSize(value)
        self.FontSize(font)

    def FontSize(self, font):
        cursor = self.plain.textCursor()
        if not cursor.hasSelection():
            cursor.select(QTextCursor.WordUnderCursor)

        cursor.mergeCharFormat(font)

    # Меню
    def new(self):
        self.plain.clear()

    # Открытие файла
    def open(self):
        try:
            self.file = QFileDialog.getOpenFileName(
                self, 'Open File', '', '(*.py);;(*.txt);;(*.css);;(*.html)')[0]
            self.openFile = open(self.file, 'r')
            self.pyTxt = self.openFile.read()
            self.plain.setPlainText(self.pyTxt)
            self.plain.setReadOnly(False)
        except IOError:
            print("UPS")
        # except UnicodeDecodeError:
        #     print('UUPs')

    # Сохранение файла
    def save(self):
        try:
            self.File = QFileDialog.getSaveFileName(
                self, 'Save File', '', '(*.py);;(*.txt);;(*.css);;(*.html)')[0]
            self.SaveFile = open(self.File, 'w')
            self.txtPy = self.plain.toPlainText()
            self.SaveFile.write(self.txtPy)
            self.plain.setReadOnly(False)
        except IOError:
            print("UPS")


if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = ClassName1()
    ex.show()
    sys.exit(app.exec_())
